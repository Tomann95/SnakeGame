# Snake Game (Konsolowy w C#)

## Jak uruchomić
1. Otwórz projekt w Visual Studio
2. Uruchom `Program.cs`
3. Sterowanie:
   - Strzałki: Ruch
   - P: Pauza

## Funkcje
- Poziomy trudności
- Pauza
- Różne rodzaje jedzenia
- Zapis wyniku
- Multiplayer (wielu graczy)

## Zasady współpracy
- Każda funkcja w osobnej gałęzi
- Pull requesty + review
- Testy po merge
