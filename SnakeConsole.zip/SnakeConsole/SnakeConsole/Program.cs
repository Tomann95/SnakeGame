﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

class Program
{
    static int width = 40; //
    static int height = 20;
    static int score = 0;
    static bool gameOver = false;
    static bool paused = false;
    static int sleepTime = 120;

    static (int x, int y) food;
    static string foodType = "normal"; // normal / bonus
    static List<(int x, int y)> snake = new List<(int x, int y)>();
    static string direction = "RIGHT";
    static Random rand = new Random();
    static int grow = 0;
    static string highscoreFile = "highscore.txt";
    static int highscore = 0;

    static void Main(string[] args)
    {
        Console.CursorVisible = false;
        Console.WriteLine("Gałąź 'feature/movement' aktywna — test zmian.");

        ChooseDifficulty();
        LoadHighScore();
        StartGame();

        while (!gameOver)
        {
            if (!paused)
            {
                Draw();
                Input();
                Logic();
                Thread.Sleep(sleepTime);
            }
            else
            {
                Input(); // tylko sprawdzanie klawisza P
                Thread.Sleep(100);
            }
        }

        Console.Clear();
        Console.WriteLine($"Koniec gry! Twój wynik: {score}");
        if (score > highscore)
        {
            Console.WriteLine("Nowy rekord!");
            File.WriteAllText(highscoreFile, score.ToString());
        }
        else
        {
            Console.WriteLine($"Najlepszy wynik: {highscore}");
        }
        Console.WriteLine("Naciśnij dowolny klawisz, aby zakończyć...");
        Console.ReadKey();
    }

    static void ChooseDifficulty()
    {
        Console.WriteLine("Wybierz poziom trudności:");
        Console.WriteLine("1 - Łatwy");
        Console.WriteLine("2 - Średni");
        Console.WriteLine("3 - Trudny");
        ConsoleKey key = Console.ReadKey(true).Key;
        switch (key)
        {
            case ConsoleKey.D1:
                sleepTime = 150;
                break;
            case ConsoleKey.D2:
                sleepTime = 100;
                break;
            case ConsoleKey.D3:
                sleepTime = 60;
                break;
            default:
                sleepTime = 100;
                break;
        }
    }

    static void LoadHighScore()
    {
        if (File.Exists(highscoreFile))
        {
            int.TryParse(File.ReadAllText(highscoreFile), out highscore);
        }
    }

    static void StartGame()
    {
        snake.Clear();
        snake.Add((10, 10));
        direction = "RIGHT";
        score = 0;
        grow = 0;
        GenerateFood();
    }

    static void GenerateFood()
    {
        do
        {
            food = (rand.Next(1, width - 1), rand.Next(1, height - 1));
        } while (snake.Contains(food));

        // 20% szansy na jedzenie bonusowe
        foodType = rand.Next(0, 5) == 0 ? "bonus" : "normal";
    }

    static void Input()
    {
        if (Console.KeyAvailable)
        {
            var key = Console.ReadKey(true).Key;
            switch (key)
            {
                case ConsoleKey.UpArrow:
                    if (direction != "DOWN") direction = "UP";
                    break;
                case ConsoleKey.DownArrow:
                    if (direction != "UP") direction = "DOWN";
                    break;
                case ConsoleKey.LeftArrow:
                    if (direction != "RIGHT") direction = "LEFT";
                    break;
                case ConsoleKey.RightArrow:
                    if (direction != "LEFT") direction = "RIGHT";
                    break;
                case ConsoleKey.P:
                    paused = !paused;
                    if (paused)
                    {
                        Console.SetCursorPosition(0, height + 2);
                        Console.Write("Gra wstrzymana. Naciśnij P, aby kontynuować...");
                    }
                    break;
            }
        }
    }

    static void Logic()
    {
        var head = snake[0];
        (int x, int y) newHead = head;

        switch (direction)
        {
            case "UP": newHead.y--; break;
            case "DOWN": newHead.y++; break;
            case "LEFT": newHead.x--; break;
            case "RIGHT": newHead.x++; break;
        }

        if (newHead.x <= 0 || newHead.x >= width - 1 || newHead.y <= 0 || newHead.y >= height - 1 || snake.Contains(newHead))
        {
            gameOver = true;
            return;
        }

        snake.Insert(0, newHead);

        if (newHead == food)
        {
            if (foodType == "bonus")
            {
                score += 5;
                grow += 5;
            }
            else
            {
                score += 1;
                grow += 3;
            }
            GenerateFood();
        }

        if (grow > 0)
        {
            grow--;
        }
        else
        {
            snake.RemoveAt(snake.Count - 1);
        }
    }

    static void Draw()
    {
        Console.Clear();

        // Granice
        for (int x = 0; x < width; x++)
        {
            Console.SetCursorPosition(x, 0); Console.Write("#");
            Console.SetCursorPosition(x, height - 1); Console.Write("#");
        }
        for (int y = 0; y < height; y++)
        {
            Console.SetCursorPosition(0, y); Console.Write("#");
            Console.SetCursorPosition(width - 1, y); Console.Write("#");
        }

        // Jedzenie
        Console.SetCursorPosition(food.x, food.y);
        Console.Write(foodType == "bonus" ? "B" : "F");

        // Wąż
        for (int i = 0; i < snake.Count; i++)
        {
            Console.SetCursorPosition(snake[i].x, snake[i].y);
            Console.Write(i == 0 ? "O" : "o");
        }

        // Statystyki
        Console.SetCursorPosition(0, height);
        Console.Write($"Wynik: {score}    Rekord: {highscore}    [P] Pauza");
    }
}
